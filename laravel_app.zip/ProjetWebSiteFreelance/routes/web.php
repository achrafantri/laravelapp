<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsersController ;
use App\Http\Controllers\ClientController ;
use App\Http\Controllers\DepotController ;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\ProjetController;
Route::get('profile',[ClientController::class,'profile']);

Route::get('/liste-projet',[ProjetController::class,'show']);
Route::get('inscription-redacteur',[UsersController::class,'create']);
Route::post('inscription-redacteur',[UsersController::class,'store']);
Route::get('inscription-client',[ClientController::class,'create']);
Route::post('inscription-client',[ClientController::class,'store']);
Route::get('depot_projet',[DepotController::class,'create']);
Route::post('depot_projet',[DepotController::class,'store']);

