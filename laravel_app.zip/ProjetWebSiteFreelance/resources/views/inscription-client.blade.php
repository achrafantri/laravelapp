@extends('template')
@section('Titre')
    Inscription Client
@endsection
@section('contenu')

    <div class=" mx-auto" style="width: 600px;">
        <div class="container-contact1">

            <form class="contact1-form validate-form" action="{{ url('inscription-client') }}" method="POST">
                @csrf
                <span class="contact1-form-title">
                    Inscription Client
                </span>
                <div class="form-row">
                    <div class="wrap-input1 validate-input col" data-validate="Name is required">
                        <input class="form-control" type="text" name="name" placeholder="Nom" required>
                        <span class="shadow-input1"></span>
                    </div>
                    <div class="wrap-input1 validate-input col" data-validate=" required">
                        <input class="form-control" type="text" name="Prenom" placeholder="Prenom" required>
                        <span class="shadow-input1"></span>
                    </div>
                </div>

                <div class="wrap-input1 validate-input" data-validate=" required">
                    <input class="form-control" type="Number" name="CIN" placeholder="CIN" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="wrap-input1 validate-input" data-validate=" required">
                    <input class="form-control" type="Number" name="naissance" placeholder="Age" required>
                    <span class="shadow-input1"></span>
                </div>

                <div class="wrap-input1 validate-input" data-validate="Valid email is required: ex@abc.xyz">
                    <input class="form-control" type="email" name="email" placeholder="Email" required>
                    <span class="shadow-input1"></span>
                </div>

                <div class="form-row">
                    <div class="wrap-input1 validate-input col" data-validate="">
                        <input class="form-control" type="password" name="mdp" placeholder="Mot de Passe " required>
                        <span class="shadow-input1"></span>
                    </div>
                    <div class="wrap-input1 validate-input col" data-validate="">
                        <input class="form-control" type="password" name="mdp2" placeholder="Confirmer le Mot de Passe "
                            required>
                        <span class="shadow-input1"></span>
                    </div>
                </div>
                <div class="container-contact1-form-btn">

                    <input type="submit" class="contact1-form-btn " value="S'inscrire">

                    <!-- <button class="contact1-form-btn">
                        <span>
                            S'inscrire
                            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                        </span>
                    </button>-->
                </div>
            </form>
        </div>
    </div>
@endsection
