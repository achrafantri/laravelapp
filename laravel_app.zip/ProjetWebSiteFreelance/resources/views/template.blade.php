<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('Titre')</title>
    <!-- Quick CSS -->
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="{{ URL::asset('css/style.css') }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{ URL::asset('css/quick-website.css') }}" id="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('vendor/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ URL::asset('fonts/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('vendor/animate/animate.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('vendor/css-hamburgers/hamburgers.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('vendor/select2/select2.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('css/util.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('css/main.css') }}">
    <script>
        window.addEventListener("load", function() {
            setTimeout(function() {
                document.querySelector('body').classList.add('loaded');
            }, 300);
        });
    </script>
</head>

<body>
    <nav class=" navbar-expand-lg navbar navbar-light  justify-content-between" style="background-color: #e3f2fd;">
        <div class="">

            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav mt-4 mt-lg-0 ml-auto">
                    <li class="nav-item ">
                        <a class="nav-link" href="{{ url('/') }}">Home</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="{{ url('profile') }}">Profile</a>
                    </li>

                    <li class="nav-item dropdown dropdown-animate" data-toggle="hover">
                        <a class="nav-link" href="{{ url('depot_projet') }}">Déposer un nouveau projet</a>
                    </li>
                </ul>
                <!-- Button -->
                <a class="navbar-btn btn btn-outline-success d-none d-lg-inline-block ml-3"
                    href="{{ url('liste-projet') }}">
                    Liste des Projets
                </a>



            </div>

        </div>
        <form class="form-inline my-2 my-lg-0 float-right">
            <input class="form-control mr-sm-2" type="search" placeholder="Search Redacteur" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
        </div>

    </nav>
    @yield('contenu')
    <script src="{{ URL::asset('vendor/jquery/jquery-3.2.1.min.js') }}"></script>
    <script src="{{ URL::asset('vendor/bootstrap/js/popper.js') }}"></script>
    <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.min.js') }}"></script>
    <script src="{{ URL::asset('vendor/select2/select2.min.js') }}"></script>
    <script src="{{ URL::asset('vendor/tilt/tilt.jquery.min.js') }}"></script>
    <script>
        $('.js-tilt').tilt({
            scale: 1.1
        })
    </script>


    <script src="js/main.js"></script>
</body>

</html>
