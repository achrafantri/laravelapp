@extends('template')
@section('Titre')
depot projet
@endsection
@section('contenu')
<!-- Preloader -->
<div class="preloader">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<div class="contact1">
    <div class=" alert alert-success" role="alert">

       <h2 class="alert-heading"> Le Depot du Projet '{{$req->input('titre')}}' et valide .   </h2>

        <br><br>
        <p> on a bien noté que le Délai de Livraison est : {{$req->input('DL')}}</p>
        <br><br>
        <p> et Le Prix est : {{$req->input('prix')}} dt</p>
        <br><br>

    </div>
    <div class="contact1-pic js-tilt" data-tilt>
        <img src="{{URL::asset('image/img-03.png')}}" alt="IMG">
    </div>
    </div>

</div>
@endsection
