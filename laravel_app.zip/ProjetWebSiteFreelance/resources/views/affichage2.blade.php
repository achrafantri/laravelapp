@extends('template')
@section('Titre')
Inscription Redacteur
@endsection
@section('contenu')
<!-- Preloader -->
<div class="preloader">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<div class="contact1">
    <div class="container-contact1">
     
       <h2> Merci  {{$req->input('name')}} ,{{$req->input('Prenom')}} </h2>
        <br>
        Nous souhaitons vous 
        remercier pour votre inscription et bienvenue sur Notre Platforme Redaction web
        <br><br>
        on a bien noté que votre  Age est : {{$req->input('naissance')}}
        <br><br>
        et que Votre E-mail est : {{$req->input('email')}}
        <br><br>
        et Votre Numero Compte Bancaire : {{$req->input('CB')}}
        <br><br>
        et Votre Mot de passe est : {{$req->input('mdp')}}
    </div>
    <div class="contact1-pic js-tilt" data-tilt>
        <img src="{{URL::asset('image/img-01.png')}}" alt="IMG">
    </div>
    </div>
 
</div>
@endsection