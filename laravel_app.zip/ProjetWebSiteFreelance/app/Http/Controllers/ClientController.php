<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function create()
    {
        return view("inscription-client");
    }

    public function profile()
    {
        return view("profile");
    }

    public function store(Request $REQUEST)
    {
return view('affichage',['req'=>$REQUEST]);

    }
}
