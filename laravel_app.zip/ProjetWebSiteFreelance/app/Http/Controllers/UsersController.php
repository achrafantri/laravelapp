<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsersController extends Controller
{
    public function create()
    {
        return view("inscription-redacteur");
    }
    

    public function store(Request $REQUEST)
    {

        return view('affichage2',['req'=>$REQUEST]);
    }

}
