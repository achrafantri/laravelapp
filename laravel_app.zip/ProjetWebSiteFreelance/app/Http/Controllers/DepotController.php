<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DepotController extends Controller
{
    public function create()
    {
        return view("depot_projet");
    }
    

    public function store(Request $REQUEST)
    {
return view('affichage3',['req'=>$REQUEST]);

    }
}
