<?php $__env->startSection('Titre'); ?>
    Depot Projet
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
    <!-- Preloader -->
    <div class="preloader">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <div class=" mx-auto" style="width: 600px;">
        <div class="container-contact1">
            <form class="contact1-form validate-form" action="<?php echo e(url('depot_projet')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <span class="contact1-form-title">
                    Dépôt Projet
                </span>
                <div class="wrap-input1 validate-input" data-validate="Name is required">
                    <input class="form-control" type="text" name="titre" placeholder="Le Titre du Projet" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="wrap-input1 validate-input" data-validate="Message is required">
                    <textarea class="form-control" name="des" placeholder="Description"></textarea>
                    <span class="shadow-input1"></span>
                </div>
                <div class="wrap-input1 validate-input" data-validate=" required">
                    <input class="form-control" type="Number" name="prix" placeholder="prix en dinars" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="wrap-input1 validate-input" data-validate=" required">
                    <label class="wrap-input1 validate-input">Délai de Livraison:</label>
                    <input class="form-control" type="date" name="DL" placeholder="" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="container-contact1-form-btn">

                    <input type="submit" class="contact1-form-btn " value="Déposer">

                    <!-- <button class="contact1-form-btn">
                        <span>
                            S'inscrire
                            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                        </span>
                    </button>-->
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjetWebSiteFreelance\resources\views/depot_projet.blade.php ENDPATH**/ ?>