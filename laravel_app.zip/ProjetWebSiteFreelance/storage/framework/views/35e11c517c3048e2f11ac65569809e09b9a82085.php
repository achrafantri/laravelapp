<?php $__env->startSection('Titre'); ?>
    Rédacteur web
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
    <!-- Preloader -->
    <div class="preloader">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" id="modal-cookies" data-backdrop="false"
        aria-labelledby="modal-cookies" aria-hidden="true">
        <div class="modal-dialog modal-dialog-aside left-4 right-4 bottom-4">
            <div class="modal-content bg-dark-dark">
            </div>
        </div>
    </div>
    <!-- Navbar -->
    <!-- Main content -->
    <section class="slice py-7 ">
        <div class="container">
            <div class="contact1-pic js-tilt rounded mx-auto d-block" data-tilt>
                <img src="<?php echo e(URL::asset('image/home.png')); ?>" alt="IMG">
            </div>
            <!-- Buttons -->
            <div class="text-center text-md-left mt-5">

                <button type="button" class="btn btn-info btn-lg btn-block float-right" data-toggle="modal"
                    data-target="#exampleModalCenter">
                    Login if u have account !
                </button>
                <a href="<?php echo e(url('inscription-client')); ?>" class="btn btn-info btn-lg btn-block float-right">
                    Inscription Client
                </a>
                <a href="<?php echo e(url('inscription-redacteur')); ?>" class="btn btn-info btn-lg btn-block float-right">
                    Inscription Rédacteur
                </a>
            </div>
            <!-- Modal -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Login</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="wrap-input1 validate-input" data-validate=" required">
                                <input class="form-control" type="Number" name="CIN" placeholder="CIN" required>
                                <span class="shadow-input1"></span>
                            </div>
                            <div class="wrap-input1 validate-input " data-validate="">
                                <input class="form-control" type="password" name="mdp" placeholder="Mot de Passe "
                                    required>
                                <span class="shadow-input1"></span>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-info">Login</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjetWebSiteFreelance\resources\views/welcome.blade.php ENDPATH**/ ?>