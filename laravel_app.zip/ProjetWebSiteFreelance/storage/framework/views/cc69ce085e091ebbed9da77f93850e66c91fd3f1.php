<?php $__env->startSection('Titre'); ?>
    Inscription Redacteur
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
    <!-- Preloader -->
    <div class="preloader">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <div class=" mx-auto" style="width: 600px;">
        <div class="container-contact1">

            <form class="contact1-form validate-form" action="<?php echo e(url('inscription-redacteur')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <span class="contact1-form-title">
                    Inscription Rédacteur
                </span>
                <div class="form-row">

                    <div class="wrap-input1 validate-input col" data-validate="Name is required">
                        <input class="form-control" type="text" name="name" placeholder="Nom" required>
                        <span class="shadow-input1"></span>
                    </div>
                    <div class="wrap-input1 validate-input col" data-validate=" required">
                        <input class="form-control" type="text" name="Prenom" placeholder="Prenom" required>
                        <span class="shadow-input1"></span>
                    </div>
                </div>

                <div class="wrap-input1 validate-input" data-validate=" required">
                    <input class="form-control" type="Number" name="naissance" placeholder="Age" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="wrap-input1 validate-input" data-validate=" required">
                    <input class="form-control" type="Number" name="CIN" placeholder="CIN" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="wrap-input1 validate-input" data-validate=" required">
                    <input class="form-control" type="text" name="CB" placeholder="Numero Compte Bancaire" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="wrap-input1 validate-input" data-validate="Valid email is required: ex@abc.xyz">
                    <input class="form-control" type="email" name="email" placeholder="Email" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="form-row">
                    <div class="wrap-input1 validate-input col" data-validate="">
                        <input class="form-control" type="password" name="mdp" placeholder="Mot de Passe " required>
                        <span class="shadow-input1"></span>
                    </div>
                    <div class="wrap-input1 validate-input col" data-validate="">
                        <input class="form-control" type="password" name="mdp2" placeholder="Confirmer le Mot de Passe "
                            required>
                        <span class="shadow-input1"></span>
                    </div>
                </div>
                <div class="wrap-input1 validate-input" data-validate="required">
                    <label>Importer Cv :</label>
                    <input class="input2" type="file" name="file" placeholder="file" required>
                    <span class="shadow-input1"></span>
                </div>
                <div class="container-contact1-form-btn">
                    <button class="contact1-form-btn">
                        <span>
                            S'inscrire
                            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\MonPremierSite\resources\views/inscription-redacteur.blade.php ENDPATH**/ ?>