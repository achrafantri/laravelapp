<?php $__env->startSection('Titre'); ?>
depot projet
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
<!-- Preloader -->
<div class="preloader">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<div class="contact1">
    <div class=" alert alert-success" role="alert">

       <h2 class="alert-heading"> Le Depot du Projet '<?php echo e($req->input('titre')); ?>' et valide .   </h2>

        <br><br>
        <p> on a bien noté que le Délai de Livraison est : <?php echo e($req->input('DL')); ?></p>
        <br><br>
        <p> et Le Prix est : <?php echo e($req->input('prix')); ?> dt</p>
        <br><br>

    </div>
    <div class="contact1-pic js-tilt" data-tilt>
        <img src="<?php echo e(URL::asset('image/img-03.png')); ?>" alt="IMG">
    </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\MonPremierSite\resources\views/affichage3.blade.php ENDPATH**/ ?>