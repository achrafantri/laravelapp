<?php $__env->startSection('Titre'); ?>
    Liste des Projets
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
    <section class="ftco-section">

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 text-center mb-5">
                    <h2 class="heading-section">Liste des Projets</h2>
                </div>
            </div>

            <?php $__currentLoopData = $p; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <br>
                <div class="card-group">
                    <div class="card " style="width: 18rem;">
                        <div class="card-body text-center">
                            <h5 class="card-title"><?php echo e($p->getTitre()); ?> </h5>
                            <h6 class="card-subtitle mb-2 text-muted"><?php echo e($p->getDelai()); ?> </h6>
                            <p class="card-text"><?php echo e($p->getDescription()); ?></p>
                            <br>
                            <a href="#" class="card-link"><?php echo e($p->getPrix()); ?> dt</a>
                            <a href="#" class="card-link btn btn-success" data-toggle="modal"
                                data-target="#exampleModal">Postuler</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo e($p->getTitre()); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <h4 class="card-subtitle mb-2 text-muted"><?php echo e($p->getDelai()); ?> </h6>
                            <h3 class="card-subtitle mb-2 text-muted"><?php echo e($p->getPrix()); ?> </h6>

                            <p class="card-text"><?php echo e($p->getDescription()); ?></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Proposer un prix</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjetWebSiteFreelance\resources\views/show_projets.blade.php ENDPATH**/ ?>