
<?php $__env->startSection('Titre'); ?>
Inscription Redacteur
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
<!-- Preloader -->
<div class="preloader">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<div class="contact1">
    <div class="container-contact1">
     
       <h2> Merci  <?php echo e($req->input('name')); ?> ,<?php echo e($req->input('Prenom')); ?> </h2>
        <br>
        Nous souhaitons vous 
        remercier pour votre inscription et bienvenue sur Notre Platforme Redaction web
        <br><br>
        on a bien noté que votre  Age est : <?php echo e($req->input('naissance')); ?>

        <br><br>
        et que Votre E-mail est : <?php echo e($req->input('email')); ?>

        <br><br>
        et Votre Numero Compte Bancaire : <?php echo e($req->input('CB')); ?>

        <br><br>
        et Votre Mot de passe est : <?php echo e($req->input('mdp')); ?>

    </div>
    <div class="contact1-pic js-tilt" data-tilt>
        <img src="<?php echo e(URL::asset('image/img-01.png')); ?>" alt="IMG">
    </div>
    </div>
 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\MonPremierSite\resources\views/affichage2.blade.php ENDPATH**/ ?>